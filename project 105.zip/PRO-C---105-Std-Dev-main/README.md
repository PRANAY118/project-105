# PRO-C---105-Std-Dev
a simple python program
